var outputfile = "",extension = "";
$( function() {
   
    var dateFormat = "mm/dd/yy",
      from = $( "#fromDate" )
        .datepicker({
          defaultDate: "+1w",
          changeMonth: true,
          changeYear: true,
          numberOfMonths: 1
        })
        .on( "change", function() {
          to.datepicker( "option", "minDate", getDate( this ) );
        }),
      to = $( "#todate" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        numberOfMonths: 2
      })
      .on( "change", function() {
        from.datepicker( "option", "maxDate", getDate( this ) );
      });
 
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }

    $("#upload-button").on("click",function(event){
      event.preventDefault();
      let valid = true;
      $(".fileuploaderror").hide();
      if($("#stockfile").val()=="" || extension == "")
      {
        $(".fileuploaderror").html("File is not uploaded").show();
        valid = false;
      }else if($("#stockfile").val()!="")
      {
        if(extension!="csv")
        {
          $(".fileuploaderror").html("Only CSV file is allowed").show();
          valid = false;
        }
      }
      if(valid)
      {
        $(".uploadForm").submit();
      }
    });



    $(".clsGetData").on("click",function(event){
      event.preventDefault();

        if(!validate()) return false;

        $.ajax({
            type: "POST",
            url: 'calculation.php',
            data: {stockname: $("#companySearchTxt").val(),stockFrom: $("#fromDate").val(),stockTo: $("#todate").val()},
            success: function(data){
              data = JSON.parse(data);
               $("#notfound").hide();
                if(data.length !=0)
                {
                   
                   $(".goal1").show();
                   $("#buyStock").html(data.buyDate);
                   $("#sellStock").html(data.sellDate);
                   $("#stockMean").html(data.meanStock);
                   $("#sdStock").html(data.standard_deviation);
                   $("#profitMade").html(data.stockProfit);
                   $(".goal2").show();
                }else {
                  
                  $("#notfound").show();
                  $(".goal1").hide();
                   $("#buyStock").html("");
                   $("#sellStock").html("");
                   $("#stockMean").html("");
                   $("#sdStock").html("");
                   $("#profitMade").html("");
                   $(".goal2").hide();
                }
                //console.log(data);
            },
            error: function(xhr, status, error){
                console.error(xhr);
            }
           });
    });

    function validate()
    {
       $(".companySearchError").hide();
       $(".daterangeError").hide();
       let valid = true;
        if($.trim($("#companySearchTxt").val()) == "")
        {
          $(".companySearchError").html("* Stock Name is Required").show();
          valid = false;
        }
        if($.trim($("#fromDate").val()) == "" || $.trim($("#todate").val()) == "")
        {
          $(".daterangeError").html("* Stock Dates is Required").show();
          valid = false;
        }else {
          var startDate  = new Date($("#fromDate").val());
          var endDate    = new Date($("#todate").val());
          if(startDate.getTime() > endDate.getTime())
          {
            $(".daterangeError").html("Start date is greater than End date").show();
            valid = false;
          }
        }
        return valid;
    }
    
  } );

  

  function validateFileName(event) {

    if (!event || !event.target || !event.target.files || event.target.files.length === 0) {
      return;
    }
  
    const name = event.target.files[0].name;
    const lastDot = name.lastIndexOf('.');
  
    const fileName = name.substring(0, lastDot);
    const ext = name.substring(lastDot + 1);
  
    outputfile = fileName;
    extension = ext;
    
  }