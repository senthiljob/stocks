// Shorthand for $( document ).ready()
$(function() {
    $("#companySearchTxt").on("keyup",function(){
        let txtValue = $(this).val().toUpperCase();
        if(txtValue.length >= 3)
        {
            $(".companylist li").each(function(){
                let liValue = $(this).data("value").toUpperCase();
                if(liValue.indexOf(txtValue) >=0)
                {
                    $(this).show();
                }else {
                    $(this).hide();
                }
            });
        }
        else if(txtValue.length < 3)
        {
            $(".companylist li").hide();
        }
    });

    $(".companylist li").on("click",function(){
        $("#companySearchTxt").val($(this).data("value"));
        $(".companylist li").hide();
    });
});